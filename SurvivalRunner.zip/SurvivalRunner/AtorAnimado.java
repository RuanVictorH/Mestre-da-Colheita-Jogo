import greenfoot.*;

/**
 * Classe AtorAnimado (subclasse de Actor)
 * 
 * Realiza as animações nos objetos que tem animação
 * 
 * @author  Davi, Layon e Marcos
 * @version 2023.11.30
 */
public class AtorAnimado extends Actor {
    // Vetor de imagens para a animação
    private GreenfootImage[] imagens;
    
    // Índice da imagem no vetor
    private int indiceImagemAtual;
    private int atualizarImagem;
    private int passosParaAtualizarImagem;
    private int passosDesdeUltimaAtualizacaoImagem;

    public AtorAnimado(GreenfootImage[] imagens, int atualizarImagem, int passosParaAtualizarImagem){
        this.imagens = imagens;
        this.atualizarImagem = atualizarImagem;
        this.passosParaAtualizarImagem = passosParaAtualizarImagem;
        passosDesdeUltimaAtualizacaoImagem = 0;
        indiceImagemAtual = 0;
    }

    public void act() {
        animar();
    }

    public void animar() {
        for (GreenfootImage imagem : imagens) {
            imagem.scale(50,50); // altero a scala das imagens p/ 50x50
        }
        passosDesdeUltimaAtualizacaoImagem++;
        if (passosDesdeUltimaAtualizacaoImagem == passosParaAtualizarImagem) {
            indiceImagemAtual++;
            if (indiceImagemAtual >= imagens.length) {
                indiceImagemAtual = 0;
            }
            setImage(imagens[indiceImagemAtual]);
            passosDesdeUltimaAtualizacaoImagem = 0;
        }
    }
}
