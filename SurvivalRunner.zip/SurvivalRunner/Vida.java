import greenfoot.*; 

/**
 * Classe Vida (subclasse de AtorAnimado)
 * 
 * Anima o coração no canto superior direito
 * 
 * @author  Davi, Layon e Marcos
 * @version 2023.11.30
 */
public class Vida extends AtorAnimado
{
    private int vida;
    private static final int NUMERO_IMAGENS = 5;
    private static GreenfootImage[] IMAGENS = new GreenfootImage[NUMERO_IMAGENS];

    static {
    for (int i = 1; i <= NUMERO_IMAGENS; i++) {
        String nomeArquivo = "Coração(" + i + ").png";
        IMAGENS[i - 1] = new GreenfootImage(nomeArquivo);
        }
    }
    
    public Vida(GreenfootImage[] imagens, int atualizarImagem, int passosParaAtualizarImagem)
    {
        super(IMAGENS, 5, 10);
        setLocation(280,21);
    }
    
    public void act()
    {
        animar();
    }
}
