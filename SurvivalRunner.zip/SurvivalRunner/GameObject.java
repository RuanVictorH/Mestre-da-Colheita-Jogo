import greenfoot.*;

/**
 * Classe GameObject (subclasse de Actor)
 * 
 * Cuida da velocidade dos objetos de sua subclasses
 * 
 * @author  Davi, Layon e Marcos
 * @version 2023.11.30
 */
public class GameObject extends Actor 
{
    private int velocidade = 1; // Velocidade inicial
    private int contagemDeTempo = 0;
    
    
    public GameObject(int velocidade, int contagemDeTempo)
    {
        this.velocidade = velocidade;
        this.contagemDeTempo = contagemDeTempo;
    }

    
    public int getVelocidade()
    {
        return velocidade;
    }
    
    public int getContagem(){
        return contagemDeTempo;
    }
    
    public int setVelocidade(int novaVelocidade){
        velocidade = novaVelocidade;
        return velocidade;
    }
    
    public void aumentarVelocidade() {
        velocidade++; // Aumenta a velocidade
    }
}
