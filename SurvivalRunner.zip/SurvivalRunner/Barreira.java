import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Barreira (subclasse de Actor)
 * 
 * Serve como as Barreiras no canto superior e inferior
 * 
 * @author  Davi, Layon e Marcos
 * @version 2023.11.30
 */
public class Barreira extends Actor
{
    public void act()
    {
        // Add your action code here.
    }
    
    public Barreira(int largura, int altura) {
        // muda o tamanho da imagem de acordo com o diâmetro passado
        getImage().scale(largura, altura);
    }
}
