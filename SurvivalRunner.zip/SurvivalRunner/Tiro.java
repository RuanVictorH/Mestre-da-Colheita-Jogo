import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Tiro (subclasse de Actor)
 * 
 * Responsável pela mecânica dos objetos tiro 
 * 
 * @author  Davi, Layon e Marcos
 * @version 2023.11.30
 */
public class Tiro extends Actor
{
    private int velocidade = 5;
    
    public void act()
    {
        moveAtaque();
    }

    public void moveAtaque() {
        int x = getX() + velocidade;  // Aumente a coordenada X de acordo com a velocidade
        int y = getY();
        int worldWidth = getWorld().getWidth();
        
        setLocation(x, y);

        if (isTouching(Zombie.class)) { // verifica se a bala vai tocar no zumbi, se encostar o zumbi esta morto
            mataZumbi();
        }
        else if(isTouching(Obstaculo.class) || isTouching(Barreira.class) || x > worldWidth){
            removerBala();  
        }
    }
    
    private void mataZumbi(){
        Zombie objetoColidido = (Zombie) getOneIntersectingObject(Zombie.class);
        if (objetoColidido != null) {
            World world = getWorld();  // Obtenha uma referência ao mundo
            world.removeObject(objetoColidido);  // Remova o Zombie do mundo
            world.removeObject(this);  // Remova o Tiro do mundo
        }
    }
    
    private void removerBala(){
        int x = getX();
        int worldWidth = getWorld().getWidth();
        // Se a bala ultrapassar o limite direito da tela, remova-a
        getWorld().removeObject(this);
        }
    }

