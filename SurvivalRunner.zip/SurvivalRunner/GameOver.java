import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe GameOver (subclasse de Actor)
 * 
 * Tem o som de grito quando você perde o jogo
 * 
 * @author  Davi, Layon e Marcos
 * @version 2023.11.30
 */
public class GameOver extends Actor {
    private GerenciadorDeSom gerenciadorDeSom;

    public GameOver() {
        gerenciadorDeSom = GerenciadorDeSom.getInstancia();
        act();
    }

    public void act() {
        acabaJogo();
    }
    
    public void acabaJogo(){
        gerenciadorDeSom.tocarSonsJogo(2);
    }
}
