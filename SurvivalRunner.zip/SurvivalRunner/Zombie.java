import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Zombie (subclasse de AtorAnimado)
 * 
 * Faz o zombie que aparece no canto esquerdo do jogo funcionar
 * 
 * @author  Davi, Layon e Marcos
 * @version 2023.11.30
 */
public class Zombie extends AtorAnimado
{
    private boolean achou;
    //teste para sprite de zumbi, se der certo, criar um metodo para isso...
    private int velocidade;

    private static final int NUMERO_IMAGENS = 9;
    private static GreenfootImage[] IMAGENS = new GreenfootImage[NUMERO_IMAGENS];

    static {
        for (int i = 1; i <= NUMERO_IMAGENS; i++) {
            String nomeArquivo =  + i +".png";
            IMAGENS[i - 1] = new GreenfootImage(nomeArquivo);
        }
    }

    public Zombie(int velocidade, int contagemDeTempo, GreenfootImage[] imagens, int atualizarImagem, int passosParaAtualizarImagem){
        super(IMAGENS, 5, 10);
        passosParaAtualizarImagem = 12;
        this.velocidade = velocidade;
    }
        
    public void act() {
        setLocation(getX() - velocidade, getY()); // Movimento contínuo para a esquerda com velocidade variável
        animar();
        
        if (isTouching(Personagem.class)) {
            mataPersonagem();
        }
        
        if (getX() <= 0) {
            removeZumbi(); // Remove o objeto do mapa
        }
    }
    
    public int setVelocidade(int vel){
        velocidade = vel;
        return vel;
    }
    
    private void removeZumbi(){
        getWorld().removeObject(this);
    }
    
    public void mataPersonagem(){
        Personagem objetoColidido = (Personagem) getOneIntersectingObject(Personagem.class);
            if (objetoColidido != null){
                objetoColidido.receberDano();
            }
    }
}
