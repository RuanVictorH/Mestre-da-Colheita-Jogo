import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Classe Placar (subclasse de World)
 * 
 * Aqui é onde veremos as "runs" antigas do jogo e o recorde do jogador
 * 
 * @author  Davi, Layon e Marcos
 * @version 2023.11.30
 */
public class Placar extends World
{
    GreenfootImage imagemFundo;
    private GerenciadorDeSom gerenciadorDeSom;
    
    private MyWorld jogo;
    private ArrayList<String> tabelaDePontuacoes;
    private int recorde = -1;
    private String pontuacaoRecorde;

    public Placar(MyWorld jogo)
    {    
        super(1025, 500, 1); // Cria um novo mundo com 1025x500 celulas com o tamanho da celula de 1x1 pixels.
        imagemFundo = new GreenfootImage(getWidth(), getHeight()); // Cria uma nova imagem com as dimensões do mundo
        setBackground("pontuacao.png");
        tabelaDePontuacoes = new ArrayList<>();
        this.jogo = jogo;
    }

    public void act()
    {
        voltar(); // volta ao jogo
    }

    public void voltar(){
        if(Greenfoot.isKeyDown("r") || Greenfoot.isKeyDown("R")){ // verifica se o jogador apertou r para reiniciar a run
            Greenfoot.setWorld(jogo);
        }
    }

    public void adicionaPontuacao(String nomeJogador, int pontuacao, String tempoJogado){
        tabelaDePontuacoes.add(nomeJogador + "    " + pontuacao + "    " + tempoJogado + "\n"); // adiciona a pontuacao da run na tabela pontuacoes
        if(pontuacao > recorde){
            pontuacaoRecorde = nomeJogador +  "    " + pontuacao + "    " + tempoJogado + "\n";
            recorde = pontuacao; // atualiza o valor do recorde de pontuacoes
        }
    }

    public String obterRecorde(){
        return pontuacaoRecorde;
    }
    
    public ArrayList obterTabela(){
        return tabelaDePontuacoes;
    }
    
    public void obterPontuacoes(){
        int k = 10; // vai percorrer ate as ultimas 10 runs.
        for(String pontuacao : tabelaDePontuacoes)
        {
            System.out.println(pontuacao);
            k++;
        }
    }
    
    public void mostraTexto(ArrayList<String> pontuacoes){
        int k = 10;
        int y = 5;
        String textoRecorde = obterRecorde();
        showText(textoRecorde, 1050-330, 6*k);
        // vai percorrer ate as ultimas 10 runs
        for(String pontuacao : tabelaDePontuacoes)
        {
            showText(pontuacao, 1050/2, 16*(k+1));
            k++;
        }
    }

}
