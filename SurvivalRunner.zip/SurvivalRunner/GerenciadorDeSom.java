import greenfoot.*;
import java.util.ArrayList;
import java.util.List; 

public class GerenciadorDeSom {
    // sons referentes ao menu e background sounds

    private static GerenciadorDeSom instancia;
    private List<GreenfootSound> sonsMenu;
    private List<GreenfootSound> sonsJogo;

    public GerenciadorDeSom() {
        inicializarSons();
    }
    
    private void inicializarSons(){
        // arrayList responsavel pelos sons do menu
        sonsMenu = new ArrayList<>();
        adicionarSom("menu_soundtrack.mp3",35,sonsMenu);
        adicionarSom("musica_historia.mp3",35,sonsMenu);
        adicionarSom("musica_ajuda.mp3",35,sonsMenu);

        // arraylist responsavel pelos sonseffect do jogo
        sonsJogo = new ArrayList<>();
        adicionarSom("soundtrack.mp3",10,sonsJogo);
        adicionarSom("cartoon_tiro.mp3",15,sonsJogo);
        adicionarSom("som_morte.mp3",10,sonsJogo);
        adicionarSom("grunido_zumbi.mp3",10,sonsJogo);
    }
    
    private void adicionarSom(String arquivo, int volume, List<GreenfootSound> lista) {
        GreenfootSound som = new GreenfootSound(arquivo);
        // som.setVolume(volume); este trecho de codigo serviria para passarmos o volume porem o greenfoot esta identificando como nulo as vezes, entao preferimos deixar o volume como padrao
        lista.add(som);
    }

    public static GerenciadorDeSom getInstancia() { // preserva a mesma instancia do gerenciador de som
        if (instancia == null) {
            instancia = new GerenciadorDeSom(); // se for nula, vai criar uma nova instancia
        }
        return instancia;
    }

    public void tocarMusicasMenu(int indice) {
        pararTodosOsSons();
        sonsMenu.get(indice).playLoop();
    }

    public void pararSomMenu() {
        pararTodosOsSons();
    }

    // som de background separado pois eh um looping ate que o jogo acabe
    public void tocarSomBackground() {
        sonsJogo.get(0).playLoop();
    }

    public void tocarSonsJogo(int indice)
    {
        sonsJogo.get(indice).play();
    }

    public void tocarSomMorte() {
        sonsJogo.get(2).play();
    }

    public void tocarSomZumbi() {
        sonsJogo.get(3).play();
    }

    private void pararTodosOsSons() {
        for (GreenfootSound som : sonsMenu) {
            som.stop();
        }
        for (GreenfootSound som : sonsJogo) {
            som.stop();
        }
    }
}