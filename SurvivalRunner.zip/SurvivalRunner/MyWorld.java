import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.GreenfootImage;
import greenfoot.GreenfootSound;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe MyWorld (subclasse de World)
 * 
 * Aqui é aonde o jogo ocorre propriamente dito. Você controla 
 * o personagem no canto esquerdo podendo movimentar ele para cima e para baixo
 * podendo atirar nos inimigos. Essa classe faz isso possível
 * 
 * @author  Davi, Layon e Marcos
 * @version 2023.11.30
 */
public class MyWorld extends World
{
    // variaveis utilizadsa na geracao dos obstaculos
    private int contagemDeTempo = 0; 
    private int intervaloDeCriacaoObstaculo = 325;
    private int intervaloDeCriacaoZombie = 325;
    private int velocidadeObstaculo = 2; 
    private int velocidadeZombie = 3; 
    private int timer = 300;

    // jogo
    private GerenciadorDeSom gerenciadorDeSom;
    private String nomeUsuario;
    private Pontuacao pontuacao;
    private Personagem personagem;
    private Vida vida; 
    private Placar placar;

    // sprites
    GreenfootImage[] imagens;
    private int atualizarImagem;
    private int passosParaAtualizarImagem;
    
    // tempo inicial que o jogo comecou
    private long tempoDeInicio;

    public MyWorld()
    {    
        super(1050, 500, 1); // Cria um novo mundo com 1050x500 celulas com o tamanho da celula de 1x1 pixels.
        nomeUsuario = "";
        prepare();
        gerenciadorDeSom = GerenciadorDeSom.getInstancia();
    }

    private void grunidosZombie() {
        if (timer > 0) {
            timer--;
        } 
        else {
            gerenciadorDeSom.tocarSomZumbi();
            timer = 300; // Reseta o timer para 5 segundos
        }
    }

    public void pedeNome(String nome){
        nome = Greenfoot.ask("Insira seu nome:"); // Pede o nome ao final da run
        if(nome == null || nome.equals("")){
            nomeUsuario = "Usuario";
        }else{
            nomeUsuario = nome;
        }
    }

    public String obterNome(){
        return nomeUsuario;
    }

    private void prepare()
    {
        personagem = new Personagem(imagens, atualizarImagem, passosParaAtualizarImagem);
        addObject(personagem,25,250);

        Barreira barreiraEmBaixo = new Barreira(2100, 200);
        addObject(barreiraEmBaixo,1,500); 

        Barreira barreiraEmCima = new Barreira(10500, 200);
        addObject(barreiraEmCima,1,1);

        pontuacao = new Pontuacao(); // nao precisa de um novo objeto pontuacao pois se criarmos um novo, perdemos o antigo...
        addObject(pontuacao,69,22);
        pontuacao.setLocation(166,21);

        vida = new Vida(imagens, atualizarImagem, passosParaAtualizarImagem);
        addObject(vida,51,51);
        pontuacao.setLocation(166,21);

        placar = new Placar(this);
        
        iniciaTempo(); // inicio o segundo que vai comecar a run
    }
    
    private void prepare(boolean morreu){ // novo prepare caso o personagem morra
        personagem = new Personagem(imagens, atualizarImagem, passosParaAtualizarImagem);
        addObject(personagem,25,250);

        Barreira barreiraEmBaixo = new Barreira(2100, 200);
        addObject(barreiraEmBaixo,1,500); 

        Barreira barreiraEmCima = new Barreira(10500, 200);
        addObject(barreiraEmCima,1,1);

        vida = new Vida(imagens, atualizarImagem, passosParaAtualizarImagem);
        addObject(vida,51,51);
        
        pontuacao = new Pontuacao(); 
        addObject(pontuacao,69,22);
        pontuacao.setLocation(166,21);

        iniciaTempo(); // inicio o segundo que vai comecar a run
    }

    public void act() {
        gerenciadorDeSom.tocarSomBackground();
        grunidosZombie();
        if(personagem.estaVivo()) {
            contagemDeTempo++;
            criacaoObstaculo();
            criacaoZombie();
            pontuacao.atualizaPontuacao(); // atualiza a pontuacao sempre que o boneco estiver vivo
        } else {
                reseta(); // reseta o mundo
                Greenfoot.setWorld(placar); // muda para placar
        }
    }

    public void reseta(){  // reinicia o jogo sem que seja necessario apertar Run
        // remove todos os obstaculos
        removeObstaculos();
        pedeNome(nomeUsuario);
        gerenciadorDeSom.pararSomMenu(); // para o som que estava rodando...
        // reinicia valores importantes para o funcionamento do jogo
        velocidadeObstaculo = 2;
        velocidadeZombie = 3;
        contagemDeTempo = 0;
        intervaloDeCriacaoZombie = 325;
        intervaloDeCriacaoObstaculo = 325;
        
        placar.adicionaPontuacao(obterNome(), pontuacao.obterPontuacao(), obterTempo());
        placar.mostraTexto(placar.obterTabela());
    
        prepare(true);
    }

    public void criacaoObstaculo(){
        contagemDeTempo++;
        if (contagemDeTempo % intervaloDeCriacaoObstaculo == 0) {
            // Define a coordenada X desejada
            int x = 1060;
            int y;
            int randomValue = Greenfoot.getRandomNumber(3);
            // Define uma das 3 cordenadas Y desejadas
            if (randomValue == 0) {
                y = 150;
            } else if (randomValue == 1) {
                y = 250;
            } else {
                y = 350;
            }
            // Cria uma nova pedra
            Obstaculo novaPedra = new Obstaculo(velocidadeObstaculo,contagemDeTempo);
            addObject(novaPedra, x, y);

            novaPedra.setVelocidade(velocidadeObstaculo);
            // Aumenta a velocidade da próxima pedra
            if (velocidadeObstaculo < 12){
                velocidadeObstaculo++; 
            }
            // Reduz o intervalo de criação das pedras à medida que o tempo passa
            if (intervaloDeCriacaoObstaculo > 85) {
                intervaloDeCriacaoObstaculo -= 15; // Reduz o intervalo a cada 250 quadros (ou ajuste conforme necessário)
            }
        }
    }

    public void criacaoZombie(){
        contagemDeTempo++;
        if (contagemDeTempo % intervaloDeCriacaoZombie == 0) {
            int x = 1060; // Define a coordenada X desejada
            int y;
            int randomValue = Greenfoot.getRandomNumber(3);
            // Define uma das 3 cordenadas Y desejadas
            if (randomValue == 0) {
                y = 150;
            } 
            else if (randomValue == 1) {
                y = 250;
            }
            else{
                y = 350;
            }
            // Cria um novo Zombie
            Zombie novoZombie = new Zombie(velocidadeZombie, contagemDeTempo,imagens, atualizarImagem, passosParaAtualizarImagem);
            addObject(novoZombie, x, y);

            novoZombie.setVelocidade(velocidadeZombie);
            // Aumenta a velocidade do próximo zombie
            if (velocidadeZombie < 13){
                velocidadeZombie++;
            }
            // Reduz o intervalo de criação dos zombies à medida que o tempo passa
            if (intervaloDeCriacaoZombie > 50) {
                intervaloDeCriacaoZombie -= 15;
            }
        }
    }
    
    public void iniciaTempo(){
        tempoDeInicio = System.currentTimeMillis(); // pegar tempo atual em milisegundos
    }
    
    public String obterTempo(){
        long tempoAtual = System.currentTimeMillis();
        long tempo = (tempoAtual - tempoDeInicio);
        
        long tempoSegundos = tempo/1000;
        long tempoMinutos = tempo/60000;
        long tempoHoras = tempo/3600000;
        
        if(tempoSegundos < 60){
            return tempoSegundos + " segundos";
        }else if(tempoMinutos < 3600){
            tempoSegundos = tempoSegundos % 60; // converte p/ segundos
            return tempoMinutos + " minutos e " + tempoSegundos + " segundos";
        }else{
            tempoMinutos = tempoMinutos % 60;
            tempoSegundos = tempoSegundos%60;
            return tempoHoras + " horas " + tempoMinutos + " minutos e " + tempoSegundos + " segundos";
        }
        
    }
    
    public void removeObstaculos() { // metodo responsavel p/ remover todos os obstaculos, vai ser utilizado quando o boneco estiver morto
        List<Obstaculo> obstaculos = getObjects(Obstaculo.class);
        List<Zombie> zumbis = getObjects(Zombie.class);
        for (Obstaculo obstaculo : obstaculos) {
            removeObject(obstaculo);
        }
        for (Zombie zombie : zumbis) {
            removeObject(zombie);
        }
    }
    
    
}