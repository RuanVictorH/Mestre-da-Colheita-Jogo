import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Personagem (subclasse de AtorAnimado)
 * 
 * Responsável pela mecânica do único personagem
 * jogável do jogo
 * 
 * @author  Davi, Layon e Marcos
 * @version 2023.11.30
 */
public class Personagem extends AtorAnimado
{
    private GerenciadorDeSom gerenciadorDeSom;
    
    private boolean teclaWPressionada = false;
    private boolean teclaSPressionada = false;
    private boolean teclaSpacePressionada = false;
    
    private int posicaoAnteriorX;
    private int posicaoAnteriorY;
    
    private boolean estaVivo;

    private static final int NUMERO_IMAGENS = 8;
    private static GreenfootImage[] IMAGENS = new GreenfootImage[NUMERO_IMAGENS];


    static {
    for (int i = 1; i <= NUMERO_IMAGENS; i++) {
        String nomeArquivo = "BonequinhoOficial(" + i + ").png";
        IMAGENS[i - 1] = new GreenfootImage(nomeArquivo);
        }
    }

    public Personagem(GreenfootImage[] imagens, int atualizarImagem, int passosParaAtualizarImagem){
        super(IMAGENS, 5, 9);
        // Criando o vetor de 6 posições, pois tem 6 imagens
        inicializar();
        gerenciadorDeSom = GerenciadorDeSom.getInstancia();
    }
    
    public boolean estaVivo(){
        return estaVivo;
    }
    
    public void inicializar(){
        estaVivo = true;
    }
    
    public void receberDano(){
        if(estaVivo){
            estaVivo = false; // SETA PARA FALSO E O PERSONAGEM MORRE
            GameOver gameover = new GameOver(); // toca o som de dano
            World world = getWorld();
            world.removeObject(this);
            gameover.acabaJogo(); // chama o grito de morte do personagem
        }
    }

    public void act()
    {
        if(estaVivo){
            if (Greenfoot.isKeyDown("w") && !teclaWPressionada) {
                moveCima();
            }
            // VERIFICA SE A TECLA ESTA PRESSIONADA
            if (!Greenfoot.isKeyDown("w")) {
                teclaWPressionada = false;
            }
            // VERIFICA SE A TECLA ESTA PRESSIONADA
            if (!Greenfoot.isKeyDown("s")) {
                teclaSPressionada = false;
            }
            
            if (Greenfoot.isKeyDown("s") && !teclaSPressionada) {
                moveBaixo();
            }
            
            if (Greenfoot.isKeyDown("space") && !teclaSpacePressionada) {
                atirar();
            }
            
            if (!Greenfoot.isKeyDown("space")) {
                teclaSpacePressionada = false;
            }
            verificaColisao();
            // atualiza sprite do personagem, deixando uma "animacao"
            animar();
        }
    }
    
    private void verificaColisao(){
        //  vai verificar se o boneco ira colidir com a barreira (entrar) se ele entrar ele retorna p/ posicao anterior, uma tecnica meio sutil para resolver o problema de colisao
        Actor barreira = getOneIntersectingObject(Barreira.class);
        if (barreira != null) {
            // O personagem colidiu com a barreira, então volta para a posição anterior rapidamente
            setLocation(posicaoAnteriorX, posicaoAnteriorY);
        }else{
            posicaoAnteriorX = getX();
            posicaoAnteriorY = getY();
        }
    }
    
    private void moveCima(){
        setLocation(getX(), getY()-100);
        teclaWPressionada = true;
    }

    private void moveBaixo(){
        setLocation(getX(), getY()+100);
        teclaSPressionada = true;
    }
    
    public void atirar(){
        gerenciadorDeSom.tocarSonsJogo(1);
        Tiro tiro = new Tiro();  // Crie uma instância do objeto Tiro
        int x = getX();  // Obtenha a coordenada X atual do objeto que está chamando o método
        int y = getY();  // Obtenha a coordenada Y atual do objeto que está chamando o método
        getWorld().addObject(tiro, x, y);  // Adicione o objeto Tiro ao mundo nas coordenadas x e y
        teclaSpacePressionada = true;
    }
}
