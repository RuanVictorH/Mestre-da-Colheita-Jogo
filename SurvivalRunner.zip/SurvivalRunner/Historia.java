import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Historia (subclasse de World)
 * 
 * Essa Classe serve para como contar uma pequena
 * história para dar contexto ao jogo.
 * 
 * @author  Davi, Layon e Marcos
 * @version 2023.11.30
 */
public class Historia extends World
{
    private GreenfootSound musica_ajuda;
    private GerenciadorDeSom gerenciadorDeSom;
    
    public Historia()
    {    
        super(1025, 500, 1); // Cria um novo mundo com 1050x500 celulas com o tamanho da celula de 1x1 pixels.
        GreenfootImage imagemFundo = new GreenfootImage(getWidth(), getHeight()); // Cria uma nova imagem com as dimensões do mundo
        setBackground("historia.png"); // Imagem com a historia do jogo
        gerenciadorDeSom = GerenciadorDeSom.getInstancia();
        gerenciadorDeSom.tocarMusicasMenu(1); // Toca a música de fundo
    }
    
        public void act()
    {
        voltar();
    }
    
    public void voltar(){
        if(Greenfoot.isKeyDown("backspace")){
            Greenfoot.setWorld(new Menu());
            gerenciadorDeSom.pararSomMenu();
        }
    }
}
