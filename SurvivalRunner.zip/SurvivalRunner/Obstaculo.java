import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Obstaculo (subclasse de GameObject)
 * 
 * Faz o obstaculo que aparece no canto esquerdo do jogo funcionar
 * 
 * @author  Davi, Layon e Marcos
 * @version 2023.11.30
 */
public class Obstaculo extends GameObject
{
    public Obstaculo(int velocidade,int contagemDeTempo)
    {
        super(velocidade,contagemDeTempo);
    }

    public void act() {
        setLocation(getX() - getVelocidade(), getY()); // Movimento contínuo para a esquerda com velocidade variável
        
        if (isTouching(Personagem.class)) {
            mataPersonagem();
        }

        if (getX() <= 0) {
            removeObstaculo(); // Remove o objeto
        }
    
    }
    
    private void removeObstaculo(){
        getWorld().removeObject(this);
    }
    
    private void mataPersonagem(){
        Personagem objetoColidido = (Personagem) getOneIntersectingObject(Personagem.class);
        if (objetoColidido != null) {
            objetoColidido.receberDano(); // pega a instacia do personagem e mata ele.
        }
    }
    
}
