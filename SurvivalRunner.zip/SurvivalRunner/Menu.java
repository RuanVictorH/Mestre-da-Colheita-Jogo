import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;

/**
 * Classe Menu (subclasse de World)
 * 
 * O jogo começa nessa classe, e nela você pode acessar
 * todas as outras subclasses do World (exceto Placar)
 * 
 * @author  Davi, Layon e Marcos
 * @version 2023.11.30
 */
public class Menu extends World
{
    private GerenciadorDeSom gerenciadorDeSom;
    /**
     * Constructor for objects of class Menu.
     * 
     */
    public Menu()
    {   
        super(1025, 500, 1); // Cria um novo mundo com 1025x500 celulas com o tamanho da celula de 1x1 pixels.
        GreenfootImage imagemFundo = new GreenfootImage(getWidth(), getHeight()); // Cria uma nova imagem com as dimensões do mundo
        setBackground("menu.png");
        gerenciadorDeSom = new GerenciadorDeSom();
        gerenciadorDeSom.tocarMusicasMenu(0); // inicializa o menu ja tocando a musica
    }

    public void act()
    {
        start();
    }

    public void start()
    {   
        // Faz os comandos escritos no menu serem possíveis
        if(Greenfoot.isKeyDown("s") || Greenfoot.isKeyDown("S"))
        {
            Greenfoot.setWorld(new MyWorld());
            gerenciadorDeSom.pararSomMenu();
        }
        else if(Greenfoot.isKeyDown("e") || Greenfoot.isKeyDown("E")){
            Greenfoot.setWorld(new Ajuda());
            gerenciadorDeSom.pararSomMenu();
        }
        else if(Greenfoot.isKeyDown("h") || Greenfoot.isKeyDown("H")){
            Greenfoot.setWorld(new Historia());
            gerenciadorDeSom.pararSomMenu();
        }
    }
}
