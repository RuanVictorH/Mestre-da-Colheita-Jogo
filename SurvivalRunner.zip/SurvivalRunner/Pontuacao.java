import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;

/**
 * Classe Pontuacao (subclasse de Actor)
 * 
 * Cuida da pontação no canto superior direito
 * 
 * @author  Davi, Layon e Marcos
 * @version 2023.11.30
 */
public class Pontuacao extends Actor
{
    private int pontuacao;
    private int timer = 0;
    
    public Pontuacao() {
        setLocation(10, 10);
        pontuacao = 0;
        atualizaPontuacao();
    }
    
    public void atualizaPontuacao(){
        setImage(new GreenfootImage("Pontuacao: " + pontuacao, 20, Color.WHITE, null));
        timer++; 
        if (timer == 15){ // timer para incrementar a pontuacao mais devagar...
            incrementaPontuacao();
            timer = 0;
        }
    }

    public void incrementaPontuacao(){
        pontuacao++;
    }
    
    public void act()
    {
        
    }
    
    public int obterPontuacao(){
        return pontuacao;
    }
}
