import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Ajuda (subclasse de World)
 * 
 * Essa Classe serve para indicar quais comandos você pode
 * realizar no jogo
 * 
 * @author  Davi, Layon e Marcos
 * @version 2023.11.30
 */
public class Ajuda extends World
{
    private GreenfootSound musica_ajuda;
    private GerenciadorDeSom gerenciadorDeSom;
    
    public Ajuda()
    {    
        super(1025, 500, 1); // Cria um novo mundo com 1025x500 celulas com o tamanho da celula de 1x1 pixels.
        GreenfootImage imagemFundo = new GreenfootImage(getWidth(), getHeight()); // Cria uma nova imagem com as dimensões do mundo
        setBackground("controle.png"); // imagem com as instruções do jogo
        gerenciadorDeSom = GerenciadorDeSom.getInstancia(); 
        gerenciadorDeSom.tocarMusicasMenu(2); // Toca a música de fundo
    }

    public void act()
    {
        voltar();
    }

    public void voltar()
    {
        if(Greenfoot.isKeyDown("backspace")){
            Greenfoot.setWorld(new Menu());
            gerenciadorDeSom.pararSomMenu();
        }
    }

}